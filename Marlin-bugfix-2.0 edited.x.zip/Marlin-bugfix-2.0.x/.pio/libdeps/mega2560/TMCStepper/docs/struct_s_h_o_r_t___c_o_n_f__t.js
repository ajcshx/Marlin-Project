var struct_s_h_o_r_t___c_o_n_f__t =
[
    [ "s2g_level", "struct_s_h_o_r_t___c_o_n_f__t.html#adb9951eb71636678ca9912a4f63da32f", null ],
    [ "s2vs_level", "struct_s_h_o_r_t___c_o_n_f__t.html#ad680e41d7a899f040e1c32de61171ec4", null ],
    [ "shortdelay", "struct_s_h_o_r_t___c_o_n_f__t.html#ae8717984e60840fdbd6a094b5ae17ef2", null ],
    [ "shortfilter", "struct_s_h_o_r_t___c_o_n_f__t.html#aece22549cb8e85787bf16ee283291417", null ],
    [ "sr", "struct_s_h_o_r_t___c_o_n_f__t.html#ae4f4ee1c6b236602314e49fa0247d537", null ]
];