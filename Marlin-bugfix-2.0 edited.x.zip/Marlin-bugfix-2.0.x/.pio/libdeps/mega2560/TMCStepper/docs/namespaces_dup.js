var namespaces_dup =
[
    [ "TMC2130_n", "namespace_t_m_c2130__n.html", null ],
    [ "TMC2160_n", "namespace_t_m_c2160__n.html", null ],
    [ "TMC2208_n", "namespace_t_m_c2208__n.html", null ],
    [ "TMC2209_n", "namespace_t_m_c2209__n.html", null ],
    [ "TMC2224_n", "namespace_t_m_c2224__n.html", null ],
    [ "TMC2660_n", "namespace_t_m_c2660__n.html", null ],
    [ "TMC5130_n", "namespace_t_m_c5130__n.html", null ]
];