var struct_d_r_v_c_o_n_f__t =
[
    [ "__pad0__", "struct_d_r_v_c_o_n_f__t.html#a57bfda9400222e096ee5f9dc7012e477", null ],
    [ "__pad1__", "struct_d_r_v_c_o_n_f__t.html#ad9e7a8320d88d2bd190019f9ad3a3673", null ],
    [ "diss2g", "struct_d_r_v_c_o_n_f__t.html#a8c019b1a2436e7791a1b04674035660f", null ],
    [ "rdsel", "struct_d_r_v_c_o_n_f__t.html#ad086c49f3588e62f98164cf040226bfe", null ],
    [ "sdoff", "struct_d_r_v_c_o_n_f__t.html#a64f0e2ec930063027732c8514797f71d", null ],
    [ "slph", "struct_d_r_v_c_o_n_f__t.html#a183ab9ad514a93548d5e58657ce742df", null ],
    [ "slpl", "struct_d_r_v_c_o_n_f__t.html#a6ccce578bc5fa3ed391952ba1983f640", null ],
    [ "sr", "struct_d_r_v_c_o_n_f__t.html#a930de3f7b432528c9a97385227b90c98", null ],
    [ "ts2g", "struct_d_r_v_c_o_n_f__t.html#ae1dfd15ceb0765adebf9b635d8c307a6", null ],
    [ "tst", "struct_d_r_v_c_o_n_f__t.html#a4e55d066ff4e99a6f24ad6b59dd419ef", null ],
    [ "vsense", "struct_d_r_v_c_o_n_f__t.html#a9a1221ddbaee0f9810bbf88801247cc7", null ]
];