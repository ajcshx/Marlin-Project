var struct_i_o_i_n__t =
[
    [ "dcen_cfg4", "struct_i_o_i_n__t.html#aee1644b2cd3ce478fd5960ef55a35f6f", null ],
    [ "dcin_cfg5", "struct_i_o_i_n__t.html#add7d4fb51523ae8a24f5e5ed419ba295", null ],
    [ "dco", "struct_i_o_i_n__t.html#a237a307c36148c4b89b9e26bc43b605b", null ],
    [ "dir", "struct_i_o_i_n__t.html#a25fc4d1a2a04553a106718cd4fc7bb5b", null ],
    [ "drv_enn_cfg6", "struct_i_o_i_n__t.html#a17bdacb8ddb5f9a9065ab0affe8fd7e8", null ],
    [ "sr", "struct_i_o_i_n__t.html#a78bda2f6a9ab0452f569fb95e980bea5", null ],
    [ "step", "struct_i_o_i_n__t.html#a8007fd85dcea337b2224d61fab84ca0d", null ],
    [ "uint16_t", "struct_i_o_i_n__t.html#a8908804e8083d1d28c600c12b7a175b0", null ],
    [ "version", "struct_i_o_i_n__t.html#accf2ad68eb9d424dd5f3725d09688542", null ]
];