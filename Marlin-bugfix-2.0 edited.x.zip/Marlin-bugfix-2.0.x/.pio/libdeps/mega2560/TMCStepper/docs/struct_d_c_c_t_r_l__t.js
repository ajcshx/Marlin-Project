var struct_d_c_c_t_r_l__t =
[
    [ "dc_sg", "struct_d_c_c_t_r_l__t.html#a9f663391d90a339be32058ed346b8bd1", null ],
    [ "dc_time", "struct_d_c_c_t_r_l__t.html#a5bffb1368dbf7276e27b28f0a5e29cb1", null ],
    [ "sr", "struct_d_c_c_t_r_l__t.html#afbb03a0028a1f1deaec871923efb876c", null ]
];