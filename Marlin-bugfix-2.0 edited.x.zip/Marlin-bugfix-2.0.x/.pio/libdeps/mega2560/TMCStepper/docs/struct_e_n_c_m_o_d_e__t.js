var struct_e_n_c_m_o_d_e__t =
[
    [ "clr_cont", "struct_e_n_c_m_o_d_e__t.html#ab0ba2afd758edba6ae7faad7a64b756a", null ],
    [ "clr_enc_x", "struct_e_n_c_m_o_d_e__t.html#a4c213595a94ed18aba3ee14c30631dd8", null ],
    [ "clr_once", "struct_e_n_c_m_o_d_e__t.html#a217b5dd9eba61f2bc1ed9f8ce32687e6", null ],
    [ "enc_sel_decimal", "struct_e_n_c_m_o_d_e__t.html#acb15b3131305e71c6bbcf89cc853c394", null ],
    [ "ignore_ab", "struct_e_n_c_m_o_d_e__t.html#abe7325f58e5cc76070bb4c77daf2995e", null ],
    [ "latch_x_act", "struct_e_n_c_m_o_d_e__t.html#a8afe8c36d6b83d49a125c920ff0edd8d", null ],
    [ "neg_edge", "struct_e_n_c_m_o_d_e__t.html#a2d4c2d8c6f8e9c08ac9ce521854e8189", null ],
    [ "pol_a", "struct_e_n_c_m_o_d_e__t.html#a90c5fbe4574fd3b03558c7935b820c9f", null ],
    [ "pol_b", "struct_e_n_c_m_o_d_e__t.html#a60bd6153b1a3cf27cd6e68b96a21dafa", null ],
    [ "pol_n", "struct_e_n_c_m_o_d_e__t.html#a6a2afb51097c992622d346dafe6b0bd3", null ],
    [ "pos_edge", "struct_e_n_c_m_o_d_e__t.html#af5ac53991ed7645b4c4e8c07b4f05f43", null ],
    [ "sr", "struct_e_n_c_m_o_d_e__t.html#ad1057444975f08f15f6d7db47cba7485", null ]
];