var searchData=
[
  ['debug_5fprint_1127',['DEBUG_PRINT',['../_t_m_c___m_a_c_r_o_s_8h.html#a246af126a51553fc72661e2b4cc9d086',1,'TMC_MACROS.h']]]
];
