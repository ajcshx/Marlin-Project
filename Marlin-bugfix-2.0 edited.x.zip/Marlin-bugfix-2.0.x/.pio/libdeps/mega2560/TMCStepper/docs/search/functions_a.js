var searchData=
[
  ['latch_5fl_5factive_728',['latch_l_active',['../class_t_m_c5130_stepper.html#a3e80083a612884058f3ff82606cfebb9',1,'TMC5130Stepper::latch_l_active(bool B)'],['../class_t_m_c5130_stepper.html#ac36c5f24698fd045718fd05f8b2eb2d8',1,'TMC5130Stepper::latch_l_active()']]],
  ['latch_5fl_5finactive_729',['latch_l_inactive',['../class_t_m_c5130_stepper.html#a9f670f76f6c5c0b0dc09b0aa31877e0e',1,'TMC5130Stepper::latch_l_inactive(bool B)'],['../class_t_m_c5130_stepper.html#a2b16739bec11e2badd0018f32815356a',1,'TMC5130Stepper::latch_l_inactive()']]],
  ['latch_5fr_5factive_730',['latch_r_active',['../class_t_m_c5130_stepper.html#a3cec6c40e109e7fed4f497c2c3d93a79',1,'TMC5130Stepper::latch_r_active(bool B)'],['../class_t_m_c5130_stepper.html#a7d5abe3fc18f1e90dc62457c199afe23',1,'TMC5130Stepper::latch_r_active()']]],
  ['latch_5fr_5finactive_731',['latch_r_inactive',['../class_t_m_c5130_stepper.html#a2ad401c53dc2ef4846ec66a19291edee',1,'TMC5130Stepper::latch_r_inactive(bool B)'],['../class_t_m_c5130_stepper.html#a491da94dbb3fb30c5a8d64674bd39f33',1,'TMC5130Stepper::latch_r_inactive()']]],
  ['latch_5fx_5fact_732',['latch_x_act',['../class_t_m_c5130_stepper.html#a86578185128aa88a67d35f7d3a5526c0',1,'TMC5130Stepper::latch_x_act(bool B)'],['../class_t_m_c5130_stepper.html#aecad025759e7e28d3d8d4ba0949de27a',1,'TMC5130Stepper::latch_x_act()']]],
  ['lost_5fsteps_733',['LOST_STEPS',['../class_t_m_c2130_stepper.html#ab5b7c77b1826da5c2e40a420880da513',1,'TMC2130Stepper']]]
];
