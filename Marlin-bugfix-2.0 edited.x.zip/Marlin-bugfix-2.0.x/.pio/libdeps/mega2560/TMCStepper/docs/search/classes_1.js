var searchData=
[
  ['chopconf_5ft_480',['CHOPCONF_t',['../struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html',1,'TMC2208_n::CHOPCONF_t'],['../struct_t_m_c2660__n_1_1_c_h_o_p_c_o_n_f__t.html',1,'TMC2660_n::CHOPCONF_t'],['../struct_c_h_o_p_c_o_n_f__t.html',1,'CHOPCONF_t']]],
  ['coolconf_5ft_481',['COOLCONF_t',['../struct_t_m_c2209__n_1_1_c_o_o_l_c_o_n_f__t.html',1,'TMC2209_n::COOLCONF_t'],['../struct_c_o_o_l_c_o_n_f__t.html',1,'COOLCONF_t']]]
];
