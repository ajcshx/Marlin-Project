var searchData=
[
  ['ca_910',['ca',['../struct_d_r_v_c_t_r_l__1__t.html#a31a48e7a247c0052e4c4bb3666e1ab33',1,'DRVCTRL_1_t']]],
  ['cb_911',['cb',['../struct_d_r_v_c_t_r_l__1__t.html#a691866098ef38fc5152040428826e3f8',1,'DRVCTRL_1_t']]],
  ['chain_5flength_912',['chain_length',['../class_t_m_c2130_stepper.html#ac679c29d1462c750e4865028f1b88040',1,'TMC2130Stepper']]],
  ['chm_913',['chm',['../struct_c_h_o_p_c_o_n_f__t.html#aa775b2014855ebd832a16615e65e1cd8',1,'CHOPCONF_t::chm()'],['../struct_t_m_c2660__n_1_1_c_h_o_p_c_o_n_f__t.html#a658081eb03bc655948f606f56294c7f4',1,'TMC2660_n::CHOPCONF_t::chm()']]],
  ['clr_5fcont_914',['clr_cont',['../struct_e_n_c_m_o_d_e__t.html#ab0ba2afd758edba6ae7faad7a64b756a',1,'ENCMODE_t']]],
  ['clr_5fenc_5fx_915',['clr_enc_x',['../struct_e_n_c_m_o_d_e__t.html#a4c213595a94ed18aba3ee14c30631dd8',1,'ENCMODE_t']]],
  ['clr_5fonce_916',['clr_once',['../struct_e_n_c_m_o_d_e__t.html#a217b5dd9eba61f2bc1ed9f8ce32687e6',1,'ENCMODE_t']]],
  ['coil_5fa_917',['coil_A',['../struct_x_d_i_r_e_c_t__t.html#a63362b0f5a7951e4b72dad4d3c34dd85',1,'XDIRECT_t']]],
  ['coil_5fb_918',['coil_B',['../struct_x_d_i_r_e_c_t__t.html#a185e2d0eb0b951ee8c46311744880d9d',1,'XDIRECT_t']]],
  ['coolconf_5fregister_919',['COOLCONF_register',['../class_t_m_c2209_stepper.html#a9d2a143190a39935b32f3814b0668de4',1,'TMC2209Stepper']]],
  ['crcerror_920',['CRCerror',['../class_t_m_c2208_stepper.html#a19238ae7c7670e558e26b5fec11697ba',1,'TMC2208Stepper']]],
  ['cs_921',['cs',['../struct_s_g_c_s_c_o_n_f__t.html#a202ff12cb42fb3cc06d1de583bc9b363',1,'SGCSCONF_t']]],
  ['cs_5factual_922',['cs_actual',['../struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#adbd64041904b2d46e1a2e1190c17ea6c',1,'TMC2130_n::DRV_STATUS_t::cs_actual()'],['../struct_t_m_c2208__n_1_1_d_r_v___s_t_a_t_u_s__t.html#adb7f1f8818d8cff3167e10ff393481f4',1,'TMC2208_n::DRV_STATUS_t::cs_actual()']]],
  ['cur_5fa_923',['cur_a',['../struct_m_s_c_u_r_a_c_t__t.html#a4e6579dc28d9e2577273093402de4d06',1,'MSCURACT_t']]],
  ['cur_5fb_924',['cur_b',['../struct_m_s_c_u_r_a_c_t__t.html#adac4398679214c4c5a29cd716a4c48b8',1,'MSCURACT_t']]]
];
