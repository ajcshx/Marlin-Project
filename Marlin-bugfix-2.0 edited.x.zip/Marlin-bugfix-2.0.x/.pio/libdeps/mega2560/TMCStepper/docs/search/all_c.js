var searchData=
[
  ['neg_5fedge_210',['neg_edge',['../struct_e_n_c_m_o_d_e__t.html#a2d4c2d8c6f8e9c08ac9ce521854e8189',1,'ENCMODE_t::neg_edge()'],['../class_t_m_c5130_stepper.html#a1779021fd601b238570769030053b8ec',1,'TMC5130Stepper::neg_edge(bool B)'],['../class_t_m_c5130_stepper.html#a6116f9f5714d5131872647944b9f76d6',1,'TMC5130Stepper::neg_edge()']]]
];
