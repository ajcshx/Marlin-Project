var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvwx",
  1: "acdefgilmoprstvx",
  2: "t",
  3: "cdegiprst",
  4: "_abcdefghilmnoprstuvwx",
  5: "_abcdefhilmnoprstuvwx",
  6: "dgirstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Macros"
};

