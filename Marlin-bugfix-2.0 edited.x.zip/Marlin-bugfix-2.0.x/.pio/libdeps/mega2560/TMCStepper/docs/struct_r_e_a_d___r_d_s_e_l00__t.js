var struct_r_e_a_d___r_d_s_e_l00__t =
[
    [ "__pad0__", "struct_r_e_a_d___r_d_s_e_l00__t.html#a3d0ce4c0e53917419da933bac2895aea", null ],
    [ "mstep", "struct_r_e_a_d___r_d_s_e_l00__t.html#ad03169210dbdb0304c73f2618c97e2be", null ],
    [ "ola", "struct_r_e_a_d___r_d_s_e_l00__t.html#aa675d8a9cb5af27e49facb001de32146", null ],
    [ "olb", "struct_r_e_a_d___r_d_s_e_l00__t.html#a93a4b2a6ccd9b215cb7829c906b17f48", null ],
    [ "ot", "struct_r_e_a_d___r_d_s_e_l00__t.html#ac88a1185bde9ccbaf9645b01c4978714", null ],
    [ "otpw", "struct_r_e_a_d___r_d_s_e_l00__t.html#a1c342725f884471a7e2d42209ce4eea5", null ],
    [ "s2ga", "struct_r_e_a_d___r_d_s_e_l00__t.html#a7aa8abea448ec2bb4e61db38304e23d9", null ],
    [ "s2gb", "struct_r_e_a_d___r_d_s_e_l00__t.html#ad2dd8beeb71828afc732a4773caa9d1e", null ],
    [ "sg_value", "struct_r_e_a_d___r_d_s_e_l00__t.html#a55f1d6c59c4890effb71410b7033646b", null ],
    [ "sr", "struct_r_e_a_d___r_d_s_e_l00__t.html#a54748338ba5db523b915c564fb9ee252", null ],
    [ "stst", "struct_r_e_a_d___r_d_s_e_l00__t.html#a166d49facb0acd1b6dec85a0880ed264", null ]
];