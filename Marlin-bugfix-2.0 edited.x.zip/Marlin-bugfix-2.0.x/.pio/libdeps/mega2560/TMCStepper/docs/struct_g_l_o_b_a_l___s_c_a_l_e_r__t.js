var struct_g_l_o_b_a_l___s_c_a_l_e_r__t =
[
    [ "sr", "struct_g_l_o_b_a_l___s_c_a_l_e_r__t.html#a701672da63ade32c0018c587d3e0d540", null ]
];