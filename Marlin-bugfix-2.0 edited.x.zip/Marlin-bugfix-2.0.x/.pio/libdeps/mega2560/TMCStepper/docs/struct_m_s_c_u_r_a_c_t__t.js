var struct_m_s_c_u_r_a_c_t__t =
[
    [ "cur_a", "struct_m_s_c_u_r_a_c_t__t.html#a4e6579dc28d9e2577273093402de4d06", null ],
    [ "cur_b", "struct_m_s_c_u_r_a_c_t__t.html#adac4398679214c4c5a29cd716a4c48b8", null ],
    [ "sr", "struct_m_s_c_u_r_a_c_t__t.html#a9fad5827d0bfe84594a9840a03cc745c", null ]
];